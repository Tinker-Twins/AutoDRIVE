% Simscape(TM) Multibody(TM) version: 7.5

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(20).translation = [0.0 0.0 0.0];
smiData.RigidTransform(20).angle = 0.0;
smiData.RigidTransform(20).axis = [0.0 0.0 0.0];
smiData.RigidTransform(20).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0.080000000000000446 0.023099999999999437 -0.065500000000000044];  % m
smiData.RigidTransform(1).angle = 0;  % rad
smiData.RigidTransform(1).axis = [0 0 0];
smiData.RigidTransform(1).ID = "B[Chassis-1:-:Right Wheel-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0.013255134952324336 0.020177501101331707 0.023098741444732451];  % m
smiData.RigidTransform(2).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(2).axis = [1 -3.2225346943134019e-32 -2.1780465113387185e-16];
smiData.RigidTransform(2).ID = "F[Chassis-1:-:Right Wheel-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 0 0];  % m
smiData.RigidTransform(3).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(3).ID = "B[Chassis-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [0 0 0];  % m
smiData.RigidTransform(4).angle = 1.5707963267948966;  % rad
smiData.RigidTransform(4).axis = [-0 -2.3551386880256629e-16 1];
smiData.RigidTransform(4).ID = "F[Chassis-1:-:]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [-0.034035865475089924 0.025750000000000012 2.3308530379348953e-15];  % m
smiData.RigidTransform(5).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962595 -0.5773502691896254 0.57735026918962595];
smiData.RigidTransform(5).ID = "B[Steering Horn-1:-:Steering Pin-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-0.03404011046208006 0.02575000000000309 0.00014565933302911407];  % m
smiData.RigidTransform(6).angle = 2.1283577490348273;  % rad
smiData.RigidTransform(6).axis = [0.55492619871355509 -0.58824183546451458 0.58824183546451614];
smiData.RigidTransform(6).ID = "F[Steering Horn-1:-:Steering Pin-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [-0.059035865475089898 0.031749999999999987 0];  % m
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [0.57735026918962584 -0.57735026918962595 0.57735026918962562];
smiData.RigidTransform(7).ID = "B[Chassis-1:-:Steering Horn-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-0.059035865475089884 0.031750000000000007 -1.1610157280017575e-13];  % m
smiData.RigidTransform(8).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(8).axis = [0.57735026918962595 -0.57735026918962618 0.57735026918962518];
smiData.RigidTransform(8).ID = "F[Chassis-1:-:Steering Horn-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 0.0029999999999999992 0.025000000000000001];  % m
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = "B[Steering Link-1:-:Steering Pin-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [-0.036537011093091452 0.012000000000002509 2.1753432388749161e-15];  % m
smiData.RigidTransform(10).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962562];
smiData.RigidTransform(10).ID = "F[Steering Link-1:-:Steering Pin-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [-0.036537011093089204 0.015800000000002281 0.037051716829166734];  % m
smiData.RigidTransform(11).angle = 2.0943951023931993;  % rad
smiData.RigidTransform(11).axis = [0.57735026918962706 -0.57735026918962695 0.57735026918962318];
smiData.RigidTransform(11).ID = "B[Steering Assembly FL-1:-:Steering Link-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-0.03705171682922058 0.0068000000000028107 0.025000000000035622];  % m
smiData.RigidTransform(12).angle = 2.0943951023931993;  % rad
smiData.RigidTransform(12).axis = [0.57735026918962695 -0.57735026918962273 0.57735026918962762];
smiData.RigidTransform(12).ID = "F[Steering Assembly FL-1:-:Steering Link-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-0.061537011093089469 -0.0049999999999999958 0.045000000000000269];  % m
smiData.RigidTransform(13).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(13).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(13).ID = "B[Chassis-1:-:Steering Assembly FL-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-0.061537011093139901 -0.0049999999999999212 0.04499999999993131];  % m
smiData.RigidTransform(14).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(14).axis = [-0.57735026918962595 -0.57735026918962562 -0.57735026918962573];
smiData.RigidTransform(14).ID = "F[Chassis-1:-:Steering Assembly FL-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-0.036537011093091584 0.015800000000005057 -0.037051716829162425];  % m
smiData.RigidTransform(15).angle = 2.0943951023931993;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962706 -0.57735026918962695 0.57735026918962318];
smiData.RigidTransform(15).ID = "B[Steering Assembly FR-1:-:Steering Link-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [0.037051716829105387 0.0068000000000056071 0.024999999999961119];  % m
smiData.RigidTransform(16).angle = 2.0943951023931993;  % rad
smiData.RigidTransform(16).axis = [0.57735026918962695 -0.57735026918962318 0.57735026918962706];
smiData.RigidTransform(16).ID = "F[Steering Assembly FR-1:-:Steering Link-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-0.061537011093092585 -0.0050000000000000096 -0.044999999999995981];  % m
smiData.RigidTransform(17).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962573 -0.57735026918962573];
smiData.RigidTransform(17).ID = "B[Chassis-1:-:Steering Assembly FR-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-0.061537011093038226 -0.0049999999999999906 -0.045000000000070331];  % m
smiData.RigidTransform(18).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(18).axis = [-0.57735026918962584 -0.57735026918962562 -0.57735026918962595];
smiData.RigidTransform(18).ID = "F[Chassis-1:-:Steering Assembly FR-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0.08000000000000157 0.022900000000000264 0.06549999999999799];  % m
smiData.RigidTransform(19).angle = 3.1415926535897896;  % rad
smiData.RigidTransform(19).axis = [1 -2.1430181468418105e-29 -1.2275695837182225e-14];
smiData.RigidTransform(19).ID = "B[Chassis-1:-:Left Wheel-1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [0.018410663749826386 0.026512842916760919 0.031074101441651923];  % m
smiData.RigidTransform(20).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(20).axis = [-1 -1.9487779556904661e-32 1.3229376432540159e-16];
smiData.RigidTransform(20).ID = "F[Chassis-1:-:Left Wheel-1]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(8).mass = 0.0;
smiData.Solid(8).CoM = [0.0 0.0 0.0];
smiData.Solid(8).MoI = [0.0 0.0 0.0];
smiData.Solid(8).PoI = [0.0 0.0 0.0];
smiData.Solid(8).color = [0.0 0.0 0.0];
smiData.Solid(8).opacity = 0.0;
smiData.Solid(8).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.0034735846350754137;  % kg
smiData.Solid(1).CoM = [-0.055484791181374844 0.025681410441789541 2.910423664704115e-15];  % m
smiData.Solid(1).MoI = [9.2640576390320789e-08 3.4342478345900162e-07 2.727959357571694e-07];  % kg*m^2
smiData.Solid(1).PoI = [0 0 1.7656386398636482e-08];  % kg*m^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = "Steering Horn*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.00031264542994627613;  % kg
smiData.Solid(2).CoM = [-0.036537011087872398 0.019137441666392203 -1.846016188357296e-09];  % m
smiData.Solid(2).MoI = [2.0614360130496901e-08 8.6961886131481768e-10 2.0599632791296556e-08];  % kg*m^2
smiData.Solid(2).PoI = [5.3938751287032398e-16 0 0];  % kg*m^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = "Steering Pin*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0023768682621798632;  % kg
smiData.Solid(3).CoM = [0 1.4999999999999998 24.999999999999996];  % mm
smiData.Solid(3).MoI = [0.02172149255691647 1.3199338655055761 1.3017776753419292];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = "Steering Link*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.84661618687549944;  % kg
smiData.Solid(4).CoM = [0.0079275969294188096 0.072808909863380719 9.8582497135903894e-05];  % m
smiData.Solid(4).MoI = [0.0032500754708184821 0.0047276461666401664 0.0064116806048669];  % kg*m^2
smiData.Solid(4).PoI = [-9.1283733709299934e-06 1.5290972894179933e-06 0.00090024341180031488];  % kg*m^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = "Chassis*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.031343927789095352;  % kg
smiData.Solid(5).CoM = [18.410664074192567 26.512842652092658 42.556269847092295];  % mm
smiData.Solid(5).MoI = [12.927512380475399 12.927044277076066 21.679196922957711];  % kg*mm^2
smiData.Solid(5).PoI = [-8.1096315704965066e-08 1.3710340436087679e-07 1.6426066454378634e-08];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = "Left Wheel*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.053045153400969589;  % kg
smiData.Solid(6).CoM = [-0.064108188357978088 0.022953061811136259 -0.06591792406094743];  % m
smiData.Solid(6).MoI = [2.5757876367795679e-05 2.7590750788282837e-05 2.8152738054641688e-05];  % kg*m^2
smiData.Solid(6).PoI = [2.5686025487157314e-07 2.2429637061218154e-06 2.4250927957092043e-07];  % kg*m^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = "Steering Assembly FR*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.053045153400971275;  % kg
smiData.Solid(7).CoM = [-0.064108188360387758 0.022953084300790228 0.065915176165505227];  % m
smiData.Solid(7).MoI = [2.5754791221203764e-05 2.758766552800485e-05 2.8152738165949333e-05];  % kg*m^2
smiData.Solid(7).PoI = [-2.5682352606139774e-07 -2.2425886434296489e-06 2.425334700125692e-07];  % kg*m^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = "Steering Assembly FL*:*Default";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.031343927789094991;  % kg
smiData.Solid(8).CoM = [13.255134623872106 20.17750084176696 34.585560236758951];  % mm
smiData.Solid(8).MoI = [12.927371139031097 12.926903036695224 21.679196922957502];  % kg*mm^2
smiData.Solid(8).PoI = [7.1323719341890553e-08 1.2838057397317707e-07 -1.7573083770160943e-08];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = "Right Wheel*:*Default";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(1).Rz.Pos = 0.0;
smiData.CylindricalJoint(1).Pz.Pos = 0.0;
smiData.CylindricalJoint(1).ID = "";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(1).Rz.Pos = -89.999999999941721;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % m
smiData.CylindricalJoint(1).ID = "[Steering Assembly FR-1:-:Steering Link-1]";


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(7).Rz.Pos = 0.0;
smiData.RevoluteJoint(7).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = -33.157619640923869;  % deg
smiData.RevoluteJoint(1).ID = "[Chassis-1:-:Right Wheel-1]";

smiData.RevoluteJoint(2).Rz.Pos = -1.1271885862902518e-10;  % deg
smiData.RevoluteJoint(2).ID = "[Chassis-1:-:Steering Horn-1]";

smiData.RevoluteJoint(3).Rz.Pos = 86.661374035838293;  % deg
smiData.RevoluteJoint(3).ID = "[Steering Link-1:-:Steering Pin-1]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(4).Rz.Pos = -89.999999999946752;  % deg
smiData.RevoluteJoint(4).ID = "[Steering Assembly FL-1:-:Steering Link-1]";

smiData.RevoluteJoint(5).Rz.Pos = 6.4196316951283723e-11;  % deg
smiData.RevoluteJoint(5).ID = "[Chassis-1:-:Steering Assembly FL-1]";

smiData.RevoluteJoint(6).Rz.Pos = 6.9221592671925296e-11;  % deg
smiData.RevoluteJoint(6).ID = "[Chassis-1:-:Steering Assembly FR-1]";

smiData.RevoluteJoint(7).Rz.Pos = -146.84238035907615;  % deg
smiData.RevoluteJoint(7).ID = "[Chassis-1:-:Left Wheel-1]";

